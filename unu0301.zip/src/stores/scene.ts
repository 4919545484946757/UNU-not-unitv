import { defineStore } from 'pinia'
import type { Entity } from '../engine/core/Entity'
import type { Scene } from '../engine/core/Scene'
import { ColliderComponent } from '../engine/components/ColliderComponent'
import { SpriteComponent } from '../engine/components/SpriteComponent'
import { TransformComponent } from '../engine/components/TransformComponent'
import { Entity as EntityClass } from '../engine/core/Entity'
import { Scene as SceneClass } from '../engine/core/Scene'
import { instantiatePrefab, serializePrefab } from '../engine/prefabs/prefabSerializer'
import { deserializeEntity, deserializeScene, serializeEntity, serializeScene } from '../engine/serialization/sceneSerializer'
import { useAssetStore } from './assets'
import { useProjectStore } from './project'
import { useSelectionStore } from './selection'

function createEntityId(prefix = 'entity') {
  return `${prefix}_${Math.random().toString(36).slice(2, 8)}`
}

function createSceneId(prefix = 'scene') {
  return `${prefix}_${Math.random().toString(36).slice(2, 8)}`
}

export const useSceneStore = defineStore('scene', {
  state: () => ({
    currentScene: null as Scene | null,
    revision: 0,
    isDirty: false
  }),
  getters: {
    entities(state): Entity[] {
      return state.currentScene?.entities ?? []
    }
  },
  actions: {
    bootstrap(scene: Scene) {
      this.currentScene = scene
      this.isDirty = false
      this.revision++
    },
    createNewScene(name = 'MainScene') {
      const project = useProjectStore()
      const selection = useSelectionStore()
      this.currentScene = new SceneClass(createSceneId('scene'), name)
      this.isDirty = true
      this.revision++
      selection.clearSelection()
      project.resetSceneFile()
      project.setStatus(`已新建场景：${name}`)
    },
    markDirty() {
      this.isDirty = true
      this.revision++
    },
    addEntity(entity: Entity) {
      if (!this.currentScene) return
      this.currentScene.addEntity(entity)
      const transform = entity.getTransform()
      if (transform) transform.zIndex = this.currentScene.entities.length - 1
      this.markDirty()
    },
    createEmptyEntity() {
      const project = useProjectStore()
      const selection = useSelectionStore()
      if (!this.currentScene) {
        this.createNewScene()
      }
      if (!this.currentScene) return
      const entity = new EntityClass(createEntityId('entity'), `Entity_${this.currentScene.entities.length + 1}`)
      entity.addComponent(new TransformComponent(0, 0, 1, 1, 0, 0.5, 0.5, this.currentScene.entities.length))
      entity.addComponent(new SpriteComponent('', 96, 96, true, 0.85, 0x56ccf2, true))
      entity.addComponent(new ColliderComponent('rect', 96, 96))
      this.currentScene.addEntity(entity)
      this.markDirty()
      selection.selectEntity(entity.id)
      project.setStatus(`已新建实体：${entity.name}`)
    },
    async createSpriteEntityFromAsset(assetPath: string, position?: { x: number; y: number }) {
      const project = useProjectStore()
      const selection = useSelectionStore()
      const assets = useAssetStore()
      if (!this.currentScene) {
        this.createNewScene()
      }
      if (!this.currentScene) {
        project.setStatus('当前没有可编辑的场景。')
        return
      }

      await assets.ensurePreview(assetPath)
      const imageSize = await assets.ensureImageSize(assetPath)
      const naturalWidth = imageSize?.width ?? 96
      const naturalHeight = imageSize?.height ?? 96
      const fitScale = Math.min(1, 192 / Math.max(naturalWidth, naturalHeight))
      const spriteWidth = Math.max(24, Math.round(naturalWidth * fitScale))
      const spriteHeight = Math.max(24, Math.round(naturalHeight * fitScale))

      const entity = new EntityClass(createEntityId('sprite'), `Sprite_${this.currentScene.entities.length + 1}`)
      entity.addComponent(
        new TransformComponent(
          position?.x ?? 320,
          position?.y ?? 220,
          1,
          1,
          0,
          0.5,
          0.5,
          this.currentScene.entities.length
        )
      )
      entity.addComponent(new SpriteComponent(assetPath, spriteWidth, spriteHeight, true, 1, 0xffffff, true))
      this.currentScene.addEntity(entity)
      this.markDirty()
      selection.selectEntity(entity.id)
      project.setStatus(`已从资源创建实体：${entity.name}`)
    },

    duplicateSelectedEntity() {
      const project = useProjectStore()
      const selection = useSelectionStore()
      const entity = this.currentScene?.getEntityById(selection.selectedEntityId)
      if (!entity || !this.currentScene) {
        project.setStatus('请先选择一个实体再复制。')
        return
      }
      const copy = deserializeEntity(serializeEntity(entity))
      copy.id = createEntityId('copy')
      copy.name = `${entity.name}_Copy`
      const transform = copy.getTransform()
      if (transform) {
        transform.x += 32
        transform.y += 32
        transform.zIndex = this.currentScene.entities.length
      }
      this.currentScene.addEntity(copy)
      this.markDirty()
      selection.selectEntity(copy.id)
      project.setStatus(`已复制实体：${entity.name}`)
    },

    removeSelectedEntity() {
      const project = useProjectStore()
      const selection = useSelectionStore()
      if (!this.currentScene || !selection.selectedEntityId) {
        project.setStatus('当前没有选中的实体可删除。')
        return
      }
      const entity = this.currentScene.getEntityById(selection.selectedEntityId)
      if (!entity) {
        selection.clearSelection()
        return
      }
      this.currentScene.removeEntityById(entity.id)
      this.currentScene.entities.forEach((item, idx) => {
        const transform = item.getTransform()
        if (transform) transform.zIndex = idx
      })
      selection.clearSelection()
      this.markDirty()
      project.setStatus(`已删除实体：${entity.name}`)
    },

    moveSelectedEntityLayer(delta: number) {
      const project = useProjectStore()
      const selection = useSelectionStore()
      if (!this.currentScene || !selection.selectedEntityId) {
        project.setStatus('请先选择一个实体再调整层级。')
        return
      }
      const entity = this.currentScene.getEntityById(selection.selectedEntityId)
      if (!entity) return
      const moved = this.currentScene.moveEntityLayer(entity.id, delta)
      if (!moved) {
        project.setStatus(delta < 0 ? '该实体已经在最底层。' : '该实体已经在最顶层。')
        return
      }
      this.markDirty()
      project.setStatus(`已调整层级：${entity.name}`)
    },
    async saveSceneAs() {
      if (!this.currentScene) return
      const project = useProjectStore()
      const assets = useAssetStore()
      const content = serializeScene(this.currentScene)
      if (!window.unu?.saveScene) {
        project.setStatus('当前为浏览器模式，未接入本地保存。')
        return
      }
      const saved = await window.unu.saveScene({
        content,
        suggestedName: `${this.currentScene.name}.scene.json`,
        projectRoot: project.rootPath
      })
      if (!saved) return
      project.setSceneFile(saved.filePath)
      project.markSaved()
      this.isDirty = false
      await assets.refreshProject()
    },
    async saveScene() {
      if (!this.currentScene) return
      const project = useProjectStore()
      if (!project.currentScenePath) {
        await this.saveSceneAs()
        return
      }
      if (!window.unu?.saveScene) {
        project.setStatus('当前为浏览器模式，未接入本地保存。')
        return
      }
      const saved = await window.unu.saveScene({
        filePath: project.currentScenePath,
        content: serializeScene(this.currentScene),
        suggestedName: `${this.currentScene.name}.scene.json`,
        projectRoot: project.rootPath
      })
      if (!saved) return
      project.markSaved()
      this.isDirty = false
    },
    async openSceneFromDisk() {
      const project = useProjectStore()
      if (!window.unu?.openScene) {
        project.setStatus('当前为浏览器模式，未接入本地打开。')
        return
      }
      const result = await window.unu.openScene({ projectRoot: project.rootPath })
      if (!result) {
        project.setStatus('已取消打开场景。')
        return
      }
      const scene = deserializeScene(result.content)
      this.currentScene = scene
      this.isDirty = false
      this.revision++
      useSelectionStore().clearSelection()
      project.setSceneFile(result.filePath)
      project.setStatus(`已打开场景：${result.name}`)
    },
    async saveSelectedAsPrefab() {
      const project = useProjectStore()
      const assets = useAssetStore()
      const selection = useSelectionStore()
      const entity = this.currentScene?.getEntityById(selection.selectedEntityId)
      if (!entity) {
        project.setStatus('请先选择一个实体再保存为 Prefab。')
        return
      }
      if (!window.unu?.savePrefab) {
        project.setStatus('当前为浏览器模式，未接入本地 Prefab 保存。')
        return
      }
      const saved = await window.unu.savePrefab({
        content: serializePrefab(entity),
        suggestedName: `${entity.name}.prefab.json`,
        projectRoot: project.rootPath
      })
      if (!saved) return
      project.setStatus(`Prefab 已保存：${saved.name}`)
      await assets.refreshProject()
    },
    async instantiatePrefabFromDisk() {
      const project = useProjectStore()
      if (!window.unu?.openPrefab) {
        project.setStatus('当前为浏览器模式，未接入本地 Prefab 打开。')
        return
      }
      const result = await window.unu.openPrefab({ projectRoot: project.rootPath })
      if (!result) {
        project.setStatus('已取消打开 Prefab。')
        return
      }
      if (!this.currentScene) {
        this.createNewScene()
      }
      if (!this.currentScene) return
      const entity = instantiatePrefab(result.content, createEntityId('prefab'))
      entity.name = `${entity.name}_Instance`
      const transform = entity.getTransform()
      if (transform) {
        transform.x += 80
        transform.y += 80
        transform.zIndex = this.currentScene.entities.length
      }
      this.currentScene.addEntity(entity)
      this.markDirty()
      useSelectionStore().selectEntity(entity.id)
      project.setStatus(`已实例化 Prefab：${result.name}`)
    }
  }
})
