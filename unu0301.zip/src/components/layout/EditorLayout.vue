<template>
  <div class="editor-shell">
    <TopToolbar />
    <div ref="mainRef" class="editor-main" :style="mainStyle">
      <LeftPanel />
      <div class="resizer left-resizer" @mousedown.prevent="startResize('left', $event)"></div>
      <CenterViewport />
      <div class="resizer right-resizer" @mousedown.prevent="startResize('right', $event)"></div>
      <RightPanel />
    </div>
  </div>
</template>

<script setup lang="ts">
import { computed, onBeforeUnmount, ref } from 'vue'
import TopToolbar from './TopToolbar.vue'
import LeftPanel from './LeftPanel.vue'
import CenterViewport from './CenterViewport.vue'
import RightPanel from './RightPanel.vue'
import { useEditorStore } from '../../stores/editor'

const editor = useEditorStore()
const RESIZER_WIDTH = 6
const MIN_CENTER_WIDTH = 320
const mainRef = ref<HTMLDivElement | null>(null)
let cleanup: (() => void) | null = null

const mainStyle = computed(() => ({
  gridTemplateColumns: `${editor.leftPanelWidth}px ${RESIZER_WIDTH}px minmax(0, 1fr) ${RESIZER_WIDTH}px ${editor.rightPanelWidth}px`
}))

function clampPanelWidths(nextLeft: number, nextRight: number) {
  const mainWidth = mainRef.value?.clientWidth ?? window.innerWidth
  const maxLeft = Math.max(220, mainWidth - RESIZER_WIDTH * 2 - editor.rightPanelWidth - MIN_CENTER_WIDTH)
  const maxRight = Math.max(240, mainWidth - RESIZER_WIDTH * 2 - editor.leftPanelWidth - MIN_CENTER_WIDTH)

  return {
    left: Math.max(220, Math.min(Math.min(640, maxLeft), nextLeft)),
    right: Math.max(240, Math.min(Math.min(720, maxRight), nextRight))
  }
}

function startResize(side: 'left' | 'right', event: MouseEvent) {
  const startX = event.clientX
  const startLeft = editor.leftPanelWidth
  const startRight = editor.rightPanelWidth

  const onMove = (moveEvent: MouseEvent) => {
    const delta = moveEvent.clientX - startX
    if (side === 'left') {
      const next = clampPanelWidths(startLeft + delta, editor.rightPanelWidth)
      editor.setLeftPanelWidth(next.left)
    } else {
      const next = clampPanelWidths(editor.leftPanelWidth, startRight - delta)
      editor.setRightPanelWidth(next.right)
    }
  }

  const onUp = () => {
    window.removeEventListener('mousemove', onMove)
    window.removeEventListener('mouseup', onUp)
    document.body.classList.remove('is-resizing-panels')
    cleanup = null
  }

  cleanup?.()
  cleanup = onUp
  document.body.classList.add('is-resizing-panels')
  window.addEventListener('mousemove', onMove)
  window.addEventListener('mouseup', onUp)
}

onBeforeUnmount(() => cleanup?.())
</script>

<style scoped>
.editor-shell {
  display: flex;
  flex-direction: column;
  height: 100%;
  background: #0e1014;
  min-width: 0;
}

.editor-main {
  display: grid;
  height: calc(100% - 52px);
  gap: 1px;
  background: #1a1f29;
  min-height: 0;
  min-width: 0;
  overflow: hidden;
}

.editor-main > * {
  min-width: 0;
  min-height: 0;
}

.resizer {
  position: relative;
  background: #151a22;
  cursor: col-resize;
  min-height: 0;
  z-index: 5;
}

.resizer::after {
  content: '';
  position: absolute;
  left: 50%;
  top: 0;
  transform: translateX(-50%);
  width: 2px;
  height: 100%;
  background: #2a3444;
}

.resizer:hover::after {
  background: #56b6c2;
}
</style>
