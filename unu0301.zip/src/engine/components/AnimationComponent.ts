import { Component } from '../core/Component'

export interface AnimationFrameData {
  texturePath: string
  duration: number
}

export interface AnimationEventData {
  frame: number
  name: string
  payload?: string
}

export interface AnimationAtlasGrid {
  columns: number
  rows: number
  cellWidth: number
  cellHeight: number
  frameCount: number
}

export class AnimationComponent extends Component {
  readonly type = 'Animation'

  constructor(
    public enabled = true,
    public playing = true,
    public fps = 8,
    public loop = true,
    public currentFrame = 0,
    public elapsed = 0,
    public framePaths: string[] = [],
    public frameDurations: number[] = [],
    public animationAssetPath = '',
    public sourceAtlasPath = '',
    public atlasGrid: AnimationAtlasGrid | null = null,
    public frameEvents: AnimationEventData[] = []
  ) {
    super()
  }
}
