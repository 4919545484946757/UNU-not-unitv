import 'pixi.js/unsafe-eval'
import { Application, Container, FederatedPointerEvent, Graphics, Rectangle, Sprite, Text, Texture } from 'pixi.js'
import { AnimationComponent } from '../components/AnimationComponent'
import { ColliderComponent } from '../components/ColliderComponent'
import { SpriteComponent } from '../components/SpriteComponent'
import { TransformComponent } from '../components/TransformComponent'
import { Scene } from '../core/Scene'
import { deserializeScene, serializeScene } from '../serialization/sceneSerializer'
import { ScriptRuntime } from '../runtime/ScriptRuntime'
import { applySceneAnimation } from '../animation/applyAnimation'
import { useAssetStore } from '../../stores/assets'
import { useEditorStore } from '../../stores/editor'
import { useProjectStore } from '../../stores/project'
import { useRuntimeStore } from '../../stores/runtime'

interface PixiRendererOptions {
  container: HTMLDivElement
  onEntitySelected?: (entityId: string) => void
  onSceneMutated?: () => void
}

type GizmoMode = 'none' | 'move' | 'scale'

export class PixiRenderer {
  private app!: Application
  private readonly root = new Container()
  private readonly world = new Container()
  private readonly overlay = new Container()
  private resizeObserver: ResizeObserver | null = null
  private readonly scriptRuntime = new ScriptRuntime()
  private sourceScene: Scene | null = null
  private playScene: Scene | null = null
  private currentScene: Scene | null = null
  private gridVisible = true
  private isPlaying = false
  private textureCache = new Map<string, Texture>()
  private selectedEntityId = ''
  private activeTool: 'select' | 'move' | 'scale' = 'select'
  private gizmoMode: GizmoMode = 'none'
  private dragOffset = { x: 0, y: 0 }
  private scaleState = { startPointerX: 0, startPointerY: 0, startScaleX: 1, startScaleY: 1 }
  private renderVersion = 0
  private renderInFlight: Promise<void> | null = null
  private queuedScene: Scene | null = null

  constructor(private readonly options: PixiRendererOptions) {}

  async init(scene: Scene | null) {
    this.app = new Application()
    await this.app.init({
      background: '#0b0f16',
      resizeTo: this.options.container,
      antialias: true
    })

    this.root.addChild(this.world)
    this.root.addChild(this.overlay)
    this.app.stage.addChild(this.root)
    this.options.container.appendChild(this.app.canvas)

    this.sourceScene = scene
    this.currentScene = scene
    this.installStageInteractions()
    this.drawGrid()
    if (scene) await this.renderScene(scene)

    this.resizeObserver = new ResizeObserver(() => {
      this.drawGrid()
      this.drawSelectionGizmo()
    })
    this.resizeObserver.observe(this.options.container)

    const runtimeStore = useRuntimeStore()
    const projectStore = useProjectStore()
    this.app.ticker.add((ticker) => {
      if (!this.currentScene) return
      const delta = ticker.deltaMS / 1000
      runtimeStore.setDeltaTime(delta)
      if (this.isPlaying) {
        this.scriptRuntime.updateScene(this.currentScene, delta)
        applySceneAnimation(this.currentScene, delta, (event) => {
          projectStore.setStatus(`动画事件：${event.name} @ frame ${event.frame}`)
        })
        void this.renderScene(this.currentScene)
      }
    })
  }

  setGridVisible(visible: boolean) {
    this.gridVisible = visible
    this.drawGrid()
  }

  setPlaying(isPlaying: boolean, scene: Scene | null) {
    this.isPlaying = isPlaying
    this.sourceScene = scene

    if (!scene) {
      this.playScene = null
      this.currentScene = null
      return
    }

    if (isPlaying) {
      this.playScene = deserializeScene(serializeScene(scene))
      this.currentScene = this.playScene
      this.resetAnimations(this.playScene)
      this.scriptRuntime.initScene(this.playScene)
      this.scriptRuntime.startScene(this.playScene)
      void this.renderScene(this.playScene)
      return
    }

    if (this.playScene) {
      this.scriptRuntime.destroyScene(this.playScene)
    }
    this.playScene = null
    this.currentScene = scene
    this.resetAnimations(scene)
    void this.renderScene(scene)
  }

  setSelection(entityId: string) {
    this.selectedEntityId = entityId
    this.drawSelectionGizmo()
  }

  setTool(tool: 'select' | 'move' | 'scale') {
    this.activeTool = tool
    this.drawSelectionGizmo()
  }

  async renderScene(scene: Scene) {
    this.currentScene = scene
    this.queuedScene = scene
    if (this.renderInFlight) {
      await this.renderInFlight
      return
    }

    this.renderInFlight = this.flushQueuedRenders()
    await this.renderInFlight
  }

  private async flushQueuedRenders() {
    while (this.queuedScene) {
      const scene = this.queuedScene
      this.queuedScene = null
      await this.renderSceneImmediate(scene)
    }
    this.renderInFlight = null
  }

  private async renderSceneImmediate(scene: Scene) {
    this.currentScene = scene
    const version = ++this.renderVersion
    const nodes: Container[] = []

    for (const entity of scene.entities) {
      const transform = entity.getComponent<TransformComponent>('Transform')
      const sprite = entity.getComponent<SpriteComponent>('Sprite')
      const collider = entity.getComponent<ColliderComponent>('Collider')
      if (!transform || !sprite) continue

      const node = new Container()
      node.label = entity.id
      node.x = transform.x
      node.y = transform.y
      node.rotation = transform.rotation
      node.scale.set(transform.scaleX, transform.scaleY)
      node.eventMode = 'static'
      node.cursor = this.isPlaying ? 'default' : 'pointer'
      node.zIndex = transform.zIndex ?? 0
      node.on('pointerdown', (event: FederatedPointerEvent) => {
        this.options.onEntitySelected?.(entity.id)
        this.selectedEntityId = entity.id
        if (this.isPlaying) return
        const local = event.getLocalPosition(this.world)
        this.dragOffset.x = local.x - transform.x
        this.dragOffset.y = local.y - transform.y
        if (this.activeTool === 'move') {
          this.gizmoMode = 'move'
        }
        event.stopPropagation()
      })

      const textureNode = await this.createSpriteNode(sprite)
      if (version !== this.renderVersion) return
      node.addChild(textureNode)

      const label = new Text({
        text: entity.name,
        style: { fill: '#ffffff', fontSize: 12 }
      })
      label.x = -sprite.width / 2
      label.y = -sprite.height / 2 - 18
      node.addChild(label)

      if (collider) {
        const colliderGfx = new Graphics()
        colliderGfx.rect(
          -collider.width / 2 + collider.offsetX,
          -collider.height / 2 + collider.offsetY,
          collider.width,
          collider.height
        )
        colliderGfx.stroke({ color: 0x00d1ff, alpha: 0.9, width: 2 })
        node.addChild(colliderGfx)
      }

      nodes.push(node)
    }

    if (version !== this.renderVersion) return

    const removable = this.world.children.filter((child) => child.label !== 'grid')
    removable.forEach((child) => child.destroy())
    nodes.sort((a, b) => (a.zIndex || 0) - (b.zIndex || 0)).forEach((node) => this.world.addChild(node))
    this.drawGrid()
    this.drawSelectionGizmo()
  }

  private installStageInteractions() {
    this.app.stage.eventMode = 'static'
    this.app.stage.hitArea = this.app.screen
    this.app.stage.on('pointerdown', () => {
      this.gizmoMode = 'none'
      if (this.activeTool === 'select') {
        this.selectedEntityId = ''
        this.options.onEntitySelected?.('')
        this.drawSelectionGizmo()
      }
    })
    this.app.stage.on('globalpointermove', (event: FederatedPointerEvent) => {
      if (!this.currentScene || this.isPlaying) return
      const entity = this.currentScene.getEntityById(this.selectedEntityId)
      const transform = entity?.getComponent<TransformComponent>('Transform')
      const sprite = entity?.getComponent<SpriteComponent>('Sprite')
      if (!entity || !transform || !sprite) return

      const local = event.getLocalPosition(this.world)
      if (this.gizmoMode === 'move') {
        transform.x = local.x - this.dragOffset.x
        transform.y = local.y - this.dragOffset.y
        this.options.onSceneMutated?.()
      } else if (this.gizmoMode === 'scale') {
        const dx = local.x - this.scaleState.startPointerX
        const dy = local.y - this.scaleState.startPointerY
        transform.scaleX = Math.max(0.1, this.scaleState.startScaleX + dx / Math.max(40, sprite.width))
        transform.scaleY = Math.max(0.1, this.scaleState.startScaleY + dy / Math.max(40, sprite.height))
        this.options.onSceneMutated?.()
      }
    })
    this.app.stage.on('pointerup', () => {
      this.gizmoMode = 'none'
    })
    this.app.stage.on('pointerupoutside', () => {
      this.gizmoMode = 'none'
    })
  }

  private async createSpriteNode(sprite: SpriteComponent) {
    const texture = await this.resolveTexture(sprite.texturePath)
    if (texture) {
      const node = new Sprite(texture)
      node.visible = sprite.visible
      node.alpha = sprite.alpha
      node.anchor.set(0.5)
      if (sprite.preserveAspect) {
        const sourceWidth = texture.width || sprite.width
        const sourceHeight = texture.height || sprite.height
        const fit = Math.min(sprite.width / Math.max(1, sourceWidth), sprite.height / Math.max(1, sourceHeight))
        node.width = Math.max(1, Math.round(sourceWidth * fit))
        node.height = Math.max(1, Math.round(sourceHeight * fit))
      } else {
        node.width = sprite.width
        node.height = sprite.height
      }
      node.tint = sprite.tint
      return node
    }

    const box = new Graphics()
    box.rect(-sprite.width / 2, -sprite.height / 2, sprite.width, sprite.height)
    box.fill({ color: sprite.tint, alpha: sprite.alpha })
    box.stroke({ color: 0xffffff, alpha: 0.35, width: 1 })
    return box
  }

  private async resolveTexture(texturePath: string) {
    if (!texturePath) return null
    if (this.textureCache.has(texturePath)) return this.textureCache.get(texturePath) ?? null

    if (texturePath.startsWith('atlas://')) {
      const texture = await this.resolveAtlasFrameTexture(texturePath)
      if (texture) this.textureCache.set(texturePath, texture)
      return texture
    }

    const assets = useAssetStore()
    const project = useProjectStore()
    const dataUrl = assets.previews[texturePath] || await assets.ensurePreview(texturePath)
    if (!dataUrl) return null
    const texture = await this.loadTextureFromDataUrl(dataUrl)
    this.textureCache.set(texturePath, texture)
    project.setStatus(`已加载贴图：${texturePath}`)
    return texture
  }


  private async loadTextureFromDataUrl(dataUrl: string) {
    const image = new Image()
    image.decoding = 'async'
    image.src = dataUrl
    await image.decode().catch(() => {
      if (image.complete) return
      return new Promise<void>((resolve, reject) => {
        image.onload = () => resolve()
        image.onerror = () => reject(new Error('图片解码失败'))
      })
    })
    return Texture.from(image)
  }

  private async resolveAtlasFrameTexture(texturePath: string) {
    const match = texturePath.match(/^atlas:\/\/(.+)#(\d+),(\d+),(\d+),(\d+)$/)
    if (!match) return null
    const [, imagePath, x, y, w, h] = match
    const baseTexture = await this.resolveTexture(imagePath)
    if (!baseTexture) return null
    const frame = new Rectangle(Number(x), Number(y), Number(w), Number(h))
    return new Texture({ source: (baseTexture as any).source, frame })
  }

  private resetAnimations(scene: Scene) {
    for (const entity of scene.entities) {
      const animation = entity.getComponent<AnimationComponent>('Animation')
      const sprite = entity.getComponent<SpriteComponent>('Sprite')
      if (!animation) continue
      animation.elapsed = 0
      animation.currentFrame = 0
      animation.playing = true
      const firstFrame = animation.framePaths[0]
      if (sprite && firstFrame) sprite.texturePath = firstFrame
    }
  }

  private drawSelectionGizmo() {
    this.overlay.removeChildren().forEach((child) => child.destroy())
    if (!this.currentScene || !this.selectedEntityId) return
    const entity = this.currentScene.getEntityById(this.selectedEntityId)
    const transform = entity?.getComponent<TransformComponent>('Transform')
    const sprite = entity?.getComponent<SpriteComponent>('Sprite')
    if (!entity || !transform || !sprite) return

    const box = new Graphics()
    box.rect(
      transform.x - (sprite.width * transform.scaleX) / 2,
      transform.y - (sprite.height * transform.scaleY) / 2,
      sprite.width * transform.scaleX,
      sprite.height * transform.scaleY
    )
    box.stroke({ color: 0x56b6c2, alpha: 1, width: 2 })

    const center = new Graphics()
    center.moveTo(transform.x - 12, transform.y)
    center.lineTo(transform.x + 12, transform.y)
    center.moveTo(transform.x, transform.y - 12)
    center.lineTo(transform.x, transform.y + 12)
    center.stroke({ color: 0x56b6c2, alpha: 0.9, width: 2 })

    this.overlay.addChild(box, center)

    const editor = useEditorStore()
    if (editor.tool === 'scale' && !this.isPlaying) {
      const handleSize = 12
      const handleX = transform.x + (sprite.width * transform.scaleX) / 2
      const handleY = transform.y + (sprite.height * transform.scaleY) / 2
      const handle = new Graphics()
      handle.roundRect(handleX - handleSize / 2, handleY - handleSize / 2, handleSize, handleSize, 3)
      handle.fill({ color: 0xf2c94c, alpha: 1 })
      handle.stroke({ color: 0xffffff, alpha: 0.9, width: 1 })
      handle.eventMode = 'static'
      handle.cursor = 'nwse-resize'
      handle.on('pointerdown', (event: FederatedPointerEvent) => {
        event.stopPropagation()
        this.gizmoMode = 'scale'
        const local = event.getLocalPosition(this.world)
        this.scaleState = {
          startPointerX: local.x,
          startPointerY: local.y,
          startScaleX: transform.scaleX,
          startScaleY: transform.scaleY
        }
      })
      this.overlay.addChild(handle)
    }
  }

  private drawGrid() {
    const existing = this.world.children.find((child) => child.label === 'grid')
    existing?.destroy()
    if (!this.gridVisible) return

    const grid = new Graphics()
    grid.label = 'grid'
    const width = this.options.container.clientWidth
    const height = this.options.container.clientHeight
    const size = 32

    for (let x = 0; x <= width; x += size) {
      grid.moveTo(x, 0)
      grid.lineTo(x, height)
    }
    for (let y = 0; y <= height; y += size) {
      grid.moveTo(0, y)
      grid.lineTo(width, y)
    }

    grid.stroke({ color: 0x263244, alpha: 0.65, width: 1 })
    this.world.addChildAt(grid, 0)
  }

  destroy() {
    if (this.playScene) {
      this.scriptRuntime.destroyScene(this.playScene)
    } else if (this.currentScene) {
      this.scriptRuntime.destroyScene(this.currentScene)
    }
    this.resizeObserver?.disconnect()
    this.app?.destroy(true, { children: true })
  }
}
