import { AnimationComponent } from '../components/AnimationComponent'
import { SpriteComponent } from '../components/SpriteComponent'
import type { Scene } from '../core/Scene'

export function getAnimationFrameDuration(animation: AnimationComponent, frameIndex: number) {
  const safeIndex = Math.max(0, Math.min(frameIndex, animation.framePaths.length - 1))
  const durationMultiplier = Math.max(1, Number(animation.frameDurations[safeIndex] ?? 1))
  return durationMultiplier / Math.max(1, animation.fps)
}

export function getAnimationTotalDuration(animation: AnimationComponent) {
  if (!animation.framePaths.length) return 0
  return animation.framePaths.reduce((sum, _frame, index) => sum + getAnimationFrameDuration(animation, index), 0)
}

export function getAnimationProgress(animation: AnimationComponent) {
  const total = getAnimationTotalDuration(animation)
  if (total <= 0 || !animation.framePaths.length) return 0

  let elapsedBeforeCurrentFrame = 0
  for (let i = 0; i < animation.currentFrame; i += 1) {
    elapsedBeforeCurrentFrame += getAnimationFrameDuration(animation, i)
  }
  return Math.max(0, Math.min(1, (elapsedBeforeCurrentFrame + animation.elapsed) / total))
}

export function applySceneAnimation(scene: Scene, delta: number, onEvent?: (payload: { entityId: string; frame: number; name: string; payload?: string }) => void) {
  for (const entity of scene.entities) {
    const animation = entity.getComponent<AnimationComponent>('Animation')
    const sprite = entity.getComponent<SpriteComponent>('Sprite')
    if (!animation || !sprite || !animation.enabled || !animation.playing) continue
    if (!animation.framePaths.length || animation.fps <= 0) continue

    animation.elapsed += delta

    while (true) {
      const frameIndex = Math.max(0, Math.min(animation.currentFrame, animation.framePaths.length - 1))
      const frameDuration = getAnimationFrameDuration(animation, frameIndex)
      if (animation.elapsed < frameDuration) break

      animation.elapsed -= frameDuration
      animation.currentFrame += 1
      if (animation.currentFrame >= animation.framePaths.length) {
        if (animation.loop) {
          animation.currentFrame = 0
        } else {
          animation.currentFrame = animation.framePaths.length - 1
          animation.playing = false
          break
        }
      }

      for (const event of animation.frameEvents) {
        if (event.frame === animation.currentFrame && event.name) {
          onEvent?.({ entityId: entity.id, frame: event.frame, name: event.name, payload: event.payload })
        }
      }
    }

    const nextPath = animation.framePaths[Math.max(0, Math.min(animation.currentFrame, animation.framePaths.length - 1))]
    if (nextPath) sprite.texturePath = nextPath
  }
}
